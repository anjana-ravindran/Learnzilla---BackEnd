﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace teamproject.Migrations
{
    public partial class firstMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblApply",
                columns: table => new
                {
                    Applyid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Regid = table.Column<int>(nullable: false),
                    Techid = table.Column<int>(nullable: false),
                    dates = table.Column<DateTime>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblApply", x => x.Applyid);
                });

            migrationBuilder.CreateTable(
                name: "tblRegister",
                columns: table => new
                {
                    Regid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(nullable: true),
                    Address = table.Column<string>(nullable: true),
                    email = table.Column<string>(nullable: true),
                    gender = table.Column<string>(nullable: true),
                    dob = table.Column<string>(nullable: true),
                    phone = table.Column<string>(nullable: true),
                    image = table.Column<string>(nullable: true),
                    username = table.Column<string>(nullable: true),
                    password = table.Column<string>(nullable: true),
                    status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRegister", x => x.Regid);
                });

            migrationBuilder.CreateTable(
                name: "tblTechRegister",
                columns: table => new
                {
                    Techid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TechnologyName = table.Column<string>(nullable: true),
                    InstituteName = table.Column<string>(nullable: true),
                    Duration = table.Column<string>(nullable: true),
                    Location = table.Column<string>(nullable: true),
                    image = table.Column<string>(nullable: true),
                    Fees = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblTechRegister", x => x.Techid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblApply");

            migrationBuilder.DropTable(
                name: "tblRegister");

            migrationBuilder.DropTable(
                name: "tblTechRegister");
        }
    }
}
