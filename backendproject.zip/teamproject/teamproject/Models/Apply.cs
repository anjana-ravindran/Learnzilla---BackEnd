﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace teamproject.Models
{
    public class Apply
    {
        [Key]
        public int Applyid { get; set; }
        public int Regid { get; set; }
        public int  Techid { get; set; }
        public DateTime dates { get; set; }
        public string Status { get; set; }
       
    }
}
