﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace teamproject.Models
{
    public class Techregister
    {
        [Key]
        public int Techid { get; set; }
        public string TechnologyName { get; set; }
        public string InstituteName { get; set; }
        public string Duration { get; set; }
        public string Location { get; set; }
        public string image { get; set; }
        public string Fees { get; set; }
        public string Description { get; set; }
        
    }
}
