﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using teamproject.Data;
using teamproject.Models;

namespace teamproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ApplyController : ControllerBase
    {
        public DataContextClass objcontextclass { get; set; }
        public ApplyController(DataContextClass teccontext)
        {
            this.objcontextclass = teccontext;
        }
        [HttpPost("applytech")]
        public async Task<ActionResult> Applytech(Apply cu)
        {
            objcontextclass.tblApply.Add(cu);
            await objcontextclass.SaveChangesAsync();
            return Ok(cu);
        }
        [HttpGet("viewapply")]
        //public async Task<List<Apply>> Viewapply()
        //{
        //    //var techuser = await (from c in objcontextclass.tblRegister join a in objcontextclass.tblApply join t in objcontextclass.tblTechRegister on
        //    //                      c.Regid equals a.Regid &
        //    //                     where c.customer_id == id select c).FirstOrDefaultAsync();
        //    //if (customers == null) { } return NotFound();
        //    //return Ok(customers);
        //    return objcontextclass.tblApply.ToList();
        //    var query = from a in objcontextclass.tblRegister
        //                join b in objcontextclass.tblApply on a.Regid equals b.Regid join
        //                c in objcontextclass.tblTechRegister on b.Techid equals c.Techid select new { tblRegister = a, tblApply = b, C = c };

        //    var results = query.ToList(); 
        //    foreach (var result in results)
        //    { Console.WriteLine(result); }



        //    }
        public IActionResult GetApply()
        {
            var result = (from C in objcontextclass.tblRegister
                          join U in objcontextclass.tblApply on C.Regid equals U.Regid
                          join b in objcontextclass.tblTechRegister on U.Techid equals b.Techid
                          where U.Status == "Applied" 
                          select new { C.Name, C.email, b.TechnologyName, b.InstituteName, b.Fees, U.Status,U.dates }).ToList();
            return Ok(result);
        }
        [HttpGet("search")]
        public async Task<IActionResult> Search()
        {
            var result = await objcontextclass.tblApply.FromSqlRaw("SELECT tblRegister.Name, tblRegister.email, tblTechRegister.TechnologyName, tblTechRegister.InstituteName, tblTechRegister.Fees, tblApply.Status,Apply.dates FROM Tblregister INNER JOIN tblApply ON tblregister.Regid=tblApply.regid INNER JOIN tblTechRegister  ON tblTechRegister.Techid=tblApply.Techid  WHERE tblApply.dates >= 'datestart' AND tblApply.dates <= 'dateend'").ToListAsync();
            return Ok(result);
        }
    }
}
