﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using teamproject.Data;
using teamproject.Models;

namespace teamproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController : ControllerBase
    {
        public DataContextClass Register { get; set; }
        public RegisterController(DataContextClass registercontext)
        {
            this.Register = registercontext;
        }
        [HttpPost("insertuser")]
        public async Task<ActionResult> InsertUser(Register cu)
        {
            Register.tblRegister.Add(cu);
            await Register.SaveChangesAsync();
            return Ok(cu);
        }

        [HttpPost("userlogin")]

        public IActionResult Login(Register user)
        {
            var userAvailable = Register.tblRegister.Where(u => u.username == user.username && u.password == user.password).FirstOrDefault();

            System.Console.WriteLine(userAvailable);
            if (userAvailable != null)
            {
                return Ok(userAvailable);
            }
            return Ok("Failed");
        }
        
        

    }
}
