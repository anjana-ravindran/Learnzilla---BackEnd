﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using teamproject.Data;
using teamproject.Models;

namespace teamproject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TechController : ControllerBase
    {
        public DataContextClass objcontextclass { get; set; }
        public TechController(DataContextClass teccontext)
        {
            this.objcontextclass = teccontext;
        }
        [HttpPost("instechnology")]
        public async Task<ActionResult> InsertTech(Techregister cu)
        {
            objcontextclass.tblTechRegister.Add(cu);
            await objcontextclass.SaveChangesAsync();
            return Ok(cu);
        }
        [HttpGet("viewtech")]
        public async Task<List<Techregister>> Viewtech()
        {
            return objcontextclass.tblTechRegister.ToList();
        }
        [HttpGet("viewtechnology")]
        public async Task<List<Techregister>> ViewTec()
        {
            return objcontextclass.tblTechRegister.ToList();
        }
        [HttpGet("ViewTechByid/{id}")]
        public IActionResult ViewTechByid(int id)
        {
            return Ok(objcontextclass.tblTechRegister.Find(id));
        }
        [HttpPost("updateTech")]
        public IActionResult updateTech(Techregister cu)
        {
            objcontextclass.tblTechRegister.Update(cu);
            objcontextclass.SaveChanges();
            return Ok(cu);
        }
        [HttpPost("deleteTech")]
        public IActionResult deleteTech(Techregister cu)
        {
            objcontextclass.tblTechRegister.Remove(cu);
            objcontextclass.SaveChanges();
            return Ok(cu);
        }
        
       
    }
}
